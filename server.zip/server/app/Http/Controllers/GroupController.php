<?php

namespace App\Http\Controllers;

use App\Models\Group;
use App\Models\Plan;
use App\Models\Reader;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class GroupController extends Controller
{
    public function index()
    {
        return Group::withCount('readers')->latest()->get();
    }

    /**
     * Lightweight group list: just the id and name for pickers.
     */
    public function indexNames()
    {
        return Group::select('id', 'name')->latest()->get();
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'name' => 'required|string|max:100|unique:groups,name',
        ]);

        $group = Group::create($data);

        return response($group->loadCount('readers'), 201);
    }

    public function show(Group $group)
    {
        $group->load('readers');

        // Attach each member's completed-day progress so the roster can show
        // a compact "Progress X of Y" indicator next to their name.
        $plan = Plan::current();
        $totalDays = $plan ? $plan->totalDays() : 0;

        $group->readers->each(function (Reader $reader) use ($plan, $totalDays) {
            $daysDone = 0;

            if ($plan && $totalDays > 0) {
                $daysDone = min($plan->daysCompletedFor($reader), $totalDays);
            }

            $reader->setAttribute('days_done', $daysDone);
            $reader->setAttribute('total_days', $totalDays);
        });

        return $group;
    }

    public function update(Request $request, Group $group)
    {
        $data = $request->validate([
            'name' => 'sometimes|required|string|max:100|unique:groups,name,'.$group->id,
        ]);

        $group->update($data);

        return $group->loadCount('readers');
    }

    public function destroy(Group $group)
    {
        $group->readers()->detach();
        $group->delete();

        return response(null, 204);
    }

    /**
     * Move a reader from this group to another one.
     */
    public function swapMember(Request $request, Group $group)
    {
        $data = $request->validate([
            'reader_id' => 'required|integer|exists:readers,id',
            'target_group_id' => 'required|integer|exists:groups,id',
        ]);

        if ((int) $data['target_group_id'] === $group->id) {
            return response(['message' => 'Pick a different group to move this reader to.'], 422);
        }        if (! $group->readers()->whereKey($data['reader_id'])->exists()) {
            return response(['message' => 'That reader is not in this group.'], 422);
        }

        $isLeader = DB::table('members')
            ->where('group_id', $group->id)
            ->where('reader_id', $data['reader_id'])
            ->value('is_leader');

        if ($isLeader) {
            return response(['message' => 'Group leaders cannot be moved to another group.'], 422);
        }

        DB::transaction(function () use ($group, $data) {
            $target = Group::findOrFail($data['target_group_id']);

            $group->readers()->detach($data['reader_id']);
            $target->readers()->syncWithoutDetaching([$data['reader_id']]);
        });

        return response([
            'group' => Group::withCount('readers')->findOrFail($group->id),
            'target' => Group::withCount('readers')->findOrFail($data['target_group_id']),
        ]);
    }

    /**
     * Mark a group member as the group's leader. A group has at most one
     * leader, so promoting someone steps down the current leader first.
     */
    public function setLeader(Request $request, Group $group, Reader $reader)
    {
        $data = $request->validate([
            'is_leader' => 'required|boolean',
        ]);

        $membership = DB::table('members')
            ->where('group_id', $group->id)
            ->where('reader_id', $reader->id)
            ->first();

        if (! $membership) {
            return response(['message' => 'That reader is not in this group.'], 422);
        }

        DB::transaction(function () use ($group, $reader, $data) {
            if ($data['is_leader']) {
                DB::table('members')
                    ->where('group_id', $group->id)
                    ->where('reader_id', '!=', $reader->id)
                    ->update([
                        'is_leader' => false,
                        'updated_at' => now(),
                    ]);
            }

            DB::table('members')
                ->where('group_id', $group->id)
                ->where('reader_id', $reader->id)
                ->update([
                    'is_leader' => $data['is_leader'],
                    'updated_at' => now(),
                ]);
        });

        return response($group->load('readers'));
    }

    /**
     * Add a reader to this group. A reader can only belong to one group, so
     * their existing membership is moved here when they already have one.
     */
    public function addMember(Request $request, Group $group)
    {
        $data = $request->validate([
            'reader_id' => 'required|integer|exists:readers,id',
        ]);

        if ($group->readers()->whereKey($data['reader_id'])->exists()) {
            return response(['message' => 'That reader is already in this group.'], 422);
        }

        DB::transaction(function () use ($group, $data) {
            DB::table('members')->where('reader_id', $data['reader_id'])->delete();

            $group->readers()->attach($data['reader_id']);
        });

        return response($group->load('readers'), 201);
    }

    /**
     * Remove a reader from this group. The reader itself is kept; only the
     * group membership is dropped.
     */
    public function removeMember(Group $group, Reader $reader)
    {
        if (! $group->readers()->whereKey($reader->id)->exists()) {
            return response(['message' => 'That reader is not in this group.'], 422);
        }

        $group->readers()->detach($reader->id);

        return response(null, 204);
    }

    /**
     * Create enough groups to hold the requested number of readers each, then
     * hand all church-member readers out evenly.
     *
     * Readers are ranked by progress first, strongest to weakest, and dealt
     * with a snake draft so every group ends up with a fair mix of stronger
     * and weaker readers and even sizes.
     */
    public function assignRandom(Request $request)
    {
        $data = $request->validate([
            'members_per_group' => 'required|integer|min:1|max:500',
        ]);

        $readers = Reader::where('is_church_member', true)->get();

        if ($readers->isEmpty()) {
            return response(['message' => 'There are no readers to assign to groups yet.'], 422);
        }

        $groupCount = (int) ceil($readers->count() / $data['members_per_group']);

        // Rank by how far each reader has got, best first. PHP keeps the
        // original (name/id) order for equal progress, so the result is
        // stable when there is no plan or nobody has read yet.
        $plan = Plan::current();

        $ranked = $readers
            ->sortByDesc(fn (Reader $reader) => $plan ? $plan->daysCompletedFor($reader) : 0)
            ->values();

        DB::transaction(function () use ($groupCount, $ranked) {
            $groups = collect(range(1, $groupCount))
                ->map(fn ($n) => Group::create(['name' => 'Group '.$n]));

            // Snake draft: strongest first, then reverse the order each round
            // so the best and weakest readers are spread across all groups.
            $groupTotal = $groups->count();

            $ranked->each(function (Reader $reader, int $index) use ($groups, $groupTotal) {
                $round = intdiv($index, $groupTotal);
                $slot = $index % $groupTotal;

                if ($round % 2 === 1) {
                    $slot = $groupTotal - 1 - $slot;
                }

                $groups[$slot]->readers()->attach($reader->id);
            });
        });

        return response(Group::withCount('readers')->latest()->get(), 201);
    }
}
